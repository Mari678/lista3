﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista3ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val;

            Console.WriteLine("Digite um valor positivo: ");
            val = double.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("Insira um valor positivo.");
                val = double.Parse(Console.ReadLine());
            } 
            while (val < 0);
        }
    }
}
