﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista3ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val1;
            double val2;

            Console.WriteLine("Digite o 1° valor: ");
            val1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 2° valor: ");
            val2 = double.Parse(Console.ReadLine());

            if (val1 > val2)
            {
                do
                {
                    Console.WriteLine("Redigite o segundo valor: ");
                    val2 = double.Parse(Console.ReadLine());
                } while (val1 > val2);
            }
        }
    }
}
