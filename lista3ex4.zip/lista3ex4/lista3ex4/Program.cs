﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista3ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int tabuada = 5;
            int cont = 0;
            int total;

            Console.WriteLine ("Tabuada do 5");

            do
            {
                cont = cont + 1;
                total = tabuada * cont;
                Console.WriteLine("{0} x {1} = {2}", tabuada, cont, total);
            } while (cont < 10);
        }
    }
}
