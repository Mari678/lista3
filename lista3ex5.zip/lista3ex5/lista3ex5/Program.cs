﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista3ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int tabuada;
            int cont = 0;
            int total;

            Console.WriteLine("Digite um valor para a tabuada: ");
            tabuada = int.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("Digite um valor positivo para a tabuada: ");
                tabuada = int.Parse(Console.ReadLine());
            } while (tabuada < 0);

            Console.WriteLine("Tabuada do {0}", tabuada);

            do
            {
                cont = cont + 1;
                total = tabuada * cont;
                Console.WriteLine("{0} x {1} = {2}", tabuada, cont, total);
            } while (cont < 10);
        }
    }
}
