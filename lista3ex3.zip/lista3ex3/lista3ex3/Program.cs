﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista3ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char mf;

            Console.WriteLine("Digite seu sexo (m ou f): ");
            mf = char.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("Redigite seu sexo (m ou f): ");
                mf = char.Parse(Console.ReadLine());
            } while (mf != 'm' && mf != 'f');
        }
    }
}
