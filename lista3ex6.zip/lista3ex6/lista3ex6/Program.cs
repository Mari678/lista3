﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista3ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int tabuada;
            int cont;
            int total;
            int va;
            int vb;

            Console.WriteLine("Digite um valor para a tabuada: ");
            tabuada = int.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("Digite um valor positivo para a tabuada: ");
                tabuada = int.Parse(Console.ReadLine());
            } while (tabuada < 0);

            Console.WriteLine("Digite o 1° valor para o intervalo: ");
            va = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 2° valor para o intervalo: ");
            vb = int.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("Redigite o 2° valor sendo este maior que o 1°: ");
                vb = int.Parse(Console.ReadLine());
            } while (vb < va);

            Console.WriteLine("Tabuada do {0} no intervalo de {1} a {2}", tabuada, vb, va);

            do
            {
                total = tabuada * vb;
                Console.WriteLine("{0} x {1} = {2}", tabuada, vb, total);
                vb = vb - 1;
            } while (vb >= va);
        }
    }
}
